
var lastWindowSessionID = -1;
var shouldCatchSessionChange = true;
var shouldSkipDiscard = false;
var focusedWindowId = 1;
var wasAppInactive = false
var isAppMode = false;
var isRestoringSession = false
var isfirstTimeReopen = true

function saveOptions(options) {
	chrome.storage.local.set(options)
}

function sendNativeMessage(message) {
   port.postMessage(message);
}

chrome.windows.getAll(function(windows) {
	var numWindows = windows.length;
		for (var i = 0; i < numWindows; i++) {
			var win = windows[i];
			lastWindowSessionID = win.sessionId;
			if (win.type == 'popup') {
				isAppMode = true
			}
		}
	}
);

function getOptions() {
   port.postMessage({options:{}});
}

var port = chrome.runtime.connectNative(nativeHost);

port.onMessage.addListener(function(msg) {
	if (typeof msg.options !== 'undefined') {
		saveOptions(msg.options)
	}
});

port.onDisconnect.addListener(function() {

});

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    sendNativeMessage(message);
});

chrome.storage.local.get(null, function(obj) {
	if (typeof obj.allow_all === 'undefined') {
		getOptions()
	}
});

openOptionsPage = function()
{
	chrome.runtime.openOptionsPage();
}

chrome.contextMenus.create({title: "Coherence Whitelist Options", contexts:["all"], onclick: openOptionsPage});

onBeforeNavigate = function(detail) {
	if (detail.frameId != 0) {
		return
	}
	let url = detail.url
	let tabId = detail.tabId
	
	if (!shouldAllowURL(url)) {
		sendNativeMessage({url: url});
		chrome.tabs.remove(tabId, function() { });
	}
}

onCreatedNavigationTarget = function(detail) {
	if (detail.frameId != 0) {
		return
	}
	let url = detail.url
	let tabId = detail.tabId
	
	if (!shouldAllowURL(url)) {
		sendNativeMessage({url: url});
		chrome.tabs.remove(tabId, function() { });
	}
}

chrome.webNavigation.onBeforeNavigate.addListener(onBeforeNavigate, {url:[{schemes: ["http", "https"]}]});

chrome.webNavigation.onCommitted.addListener(onBeforeNavigate, {url:[{schemes: ["http", "https"]}]});

chrome.webNavigation.onCreatedNavigationTarget.addListener(onCreatedNavigationTarget, {url:[{schemes: ["http", "https"]}]});

var handler = function( details ) {
    var headers = details.requestHeaders,
      blockingResponse = {};

    for( var i = 0, l = headers.length; i < l; ++i ) {
      if( headers[i].name == 'User-Agent' ) {
        headers[i].value = 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.10; rv:75.0) Gecko/20100101 Firefox/75.0';
        break;
      }
    }

    blockingResponse.requestHeaders = headers;
    return blockingResponse;
  };

chrome.webRequest.onBeforeSendHeaders.addListener( handler, {
    urls: [ "https://accounts.google.com/*" ]
  }, ['requestHeaders','blocking'] );


onWindowsCreated = function(detail) {
	console.log("onWindowsCreated", detail);
	if (shouldSkipDiscard) {
		shouldSkipDiscard = false;
		return;
	}

	if (lastWindowSessionID == -1) {
		return;
	}

	chrome.windows.getAll(function(windows) {
		if (windows.length == 1) {
			shouldSkipDiscard = true;
			shouldCatchSessionChange = false;
			isRestoringSession = true

			chrome.windows.remove(detail.id);
			chrome.sessions.restore(lastWindowSessionID);
		}
		else {
			if (isAppMode && wasAppInactive || isfirstTimeReopen ) {
					wasAppInactive = false
					isfirstTimeReopen = false
					chrome.windows.remove(detail.id);
				}
		}
	});
}

onSessionsChanged = function() {
	console.log("onSessionsChanged");
	if (!shouldCatchSessionChange) {
		shouldCatchSessionChange = true;
		console.log("getRecentlyClosed", "shouldCatchSessionChange");
		return;
	}

	chrome.sessions.getRecentlyClosed({maxResults: 1}, function(sessions) {
		if (sessions.length == 0) {
			return;
		}
		var session = sessions[0];
		console.log("getRecentlyClosed", session);
		if (typeof session.window !== 'undefined') {
			lastWindowSessionID = session.window.sessionId;
			console.log("onSessionsChanged", lastWindowSessionID);
		}
	});
}

chrome.windows.onFocusChanged.addListener(function(windowId) {
	focusedWindowId = windowId;
	if (windowId == -1) {
		wasAppInactive = true
	}
});

chrome.windows.onCreated.addListener(onWindowsCreated);
chrome.sessions.onChanged.addListener(onSessionsChanged);
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
            // console.log("tabId " + tabId + " changeInfo " + changeInfo + " tab " + tab.url);
            if (tab.url == "chrome://newtab/") {
                  //  chrome.windows.remove(tab.windowId);
                    chrome.tabs.remove(tabId, function() { });
            }
     }
);
