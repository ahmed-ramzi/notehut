function isLink(e) {
    return e && e.tagName && "string" == typeof e.tagName && "a" == e.tagName.toLowerCase()
}

function getPosition(string, subString, index) {
   return string.split(subString, index).join(subString).length;
}

window.open = function (url, windowName, windowFeatures) {
    chrome.runtime.sendMessage({url: url})
};

window.onclick = function (e) {
	e = e || window.e;
    var target = e.target || e.srcElement;

    while (target) {
      if (target instanceof HTMLAnchorElement) {
        break;
      }

      target = target.parentNode;
    }
	
    if (isLink(target)) {
    	var url = target.href;
    	if (!shouldAllowURL(url)) {
    		chrome.runtime.sendMessage({url: url})
	    	e.preventDefault()
	    	e.stopPropagation()
			return false;
		}
    }
}
