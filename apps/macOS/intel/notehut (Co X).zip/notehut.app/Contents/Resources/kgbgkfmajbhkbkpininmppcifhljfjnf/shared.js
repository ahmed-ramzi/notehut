var options = {}

function updateOptions() {
	chrome.storage.local.get(null, function(obj) {
		var allow_all = true;
		var allow_rules = false;
		var allow_from_list = 0;
		var allow_subdomains = false;
		var rule_list = [];

		if (typeof obj.allow_all !== 'undefined') {
			allow_all = obj.allow_all;
		}

		if (typeof obj.allow_rules !== 'undefined') {
			allow_rules = obj.allow_rules;
		}

		if (typeof obj.allow_from_list !== 'undefined') {
			allow_from_list = obj.allow_from_list;
               //console.log("obj.allow_from_list !undefined:", allow_from_list);
		}

		if (typeof obj.allow_subdomains !== 'undefined') {
			allow_subdomains = obj.allow_subdomains;
		}

		if (typeof obj.rule_list !== 'undefined') {
			rule_list = obj.rule_list;
		}

		options = {
			allow_all: allow_all,
			allow_rules: allow_rules,
			allow_from_list: allow_from_list,
			allow_subdomains: allow_subdomains,
			rule_list: rule_list
		}
	});
}

updateOptions();

chrome.storage.onChanged.addListener(function() {
	updateOptions();
});

function mainDomain(url) {
	let domain = url.replace('http://','').replace('https://','').split(/[/?#]/)[0];
	let domain_parts = domain.split(".")
	if (domain_parts.length > 1) {
		return domain_parts[domain_parts.length-2] + "." + domain_parts[domain_parts.length-1];
	} else {
		return ""
	}
}
function removeProtocol(url){
        // startsWith

        if(url.startsWith("www.")){
                const www = "www."
                return url.slice(www.length)
        }

        if(url.startsWith("https://www.")){
                const https = "https://www."
                // slice() method
                return url.slice(https.length)
        }

        if(url.startsWith("http://www.")){
                const http = "http://www."
                return url.slice(http.length)
        }

        if(url.startsWith("https://")){
                const https = "https://"
                return url.slice(https.length)
        }

        if(url.startsWith('http://')){
                const http = "http://"
                return url.slice(http.length)
        }

        // url is correct

        return url
}

function shouldAllowURL(url) {

    if (options.allow_all) {
        return true;
    }
    var domainURL = removeProtocol(url);
    var patternAllowed = false;

    for (var index = 0; index < options.rule_list.length; index++) {
        let pattern = options.rule_list[index];
        var parts = pattern.split("*");
        var patternFound = true;
        var position = 0;

        for (var partIndex = 0; partIndex < parts.length; partIndex++) {
            let part = removeProtocol(parts[partIndex]);
            //console.log("part:", part);

            if (part.length == 0) {
                continue;
            }
            var location = domainURL.indexOf(part);

            if (partIndex == 0) {
                if (options.allow_subdomains) {
                    let domain = mainDomain(part)
                    if (domain.length > 0){
                        location = domainURL.indexOf(domain)
                    }
                }
            }

            if (location == -1) {
                patternFound = false;
                break;
            }

            if (location < position) {
                patternFound = false;
                break;
            }

            position = location;
        }

        if (patternFound)
        {
            patternAllowed = true;
            break;
        }
    }
//console.log("patternAllowed:", patternAllowed);
//console.log("options.allow_from_list:", options.allow_from_list);

    if (patternAllowed) {
        return !options.allow_from_list;
    } else {
        return options.allow_from_list;
    }
}
