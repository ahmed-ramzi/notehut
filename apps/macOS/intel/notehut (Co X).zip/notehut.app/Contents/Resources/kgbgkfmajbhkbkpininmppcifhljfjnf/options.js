function addRule() {
	var rule = prompt("Please enter url rule. i.e. http://www.google.com"); 
	var rule_list = document.getElementById("rule-list");
	var opt = document.createElement('option');
	opt.appendChild( document.createTextNode(rule));
	opt.value = rule; 
	rule_list.appendChild(opt); 
	updateRules()
}

function removeRule() {
	var rule_list = document.getElementById("rule-list");
	for (var i = 0; i < rule_list.options.length; i++) {
        if (rule_list.options[i].selected) {
            rule_list.removeChild(rule_list.options[i]);
        }
    }
    updateRules()
}

function updateRules() {
	var rule_list = document.getElementById("rule-list");
	var rules = [];
	for (var i = 0; i < rule_list.options.length; i++) {
        rules.push(rule_list.options[i].value)
    }
    chrome.storage.local.set({"rule_list": rules})
}

function allowSubdomainCheckboxEvent() {
	chrome.storage.local.set({"allow_subdomains": document.getElementById("allow_subdomains").checked})
}

function allowRuleRadioEvent() {
	if (document.getElementById("allow_all").checked) {
		chrome.storage.local.set({"allow_all": true})
		chrome.storage.local.set({"allow_rules": false})
	} else if (document.getElementById("allow_rules").checked) {
		chrome.storage.local.set({"allow_all": false})
		chrome.storage.local.set({"allow_rules": true})
	}
}

function allowRuleSelectEvent() {
	chrome.storage.local.set({"allow_from_list": document.getElementById("allow_from_list").selectedIndex})
}

function initialise() {

	chrome.storage.local.get(null, function(obj) {

		var allow_all = true;
		var allow_rules = false;
		var allow_from_list = 0;
		var allow_subdomains = false;
		var rule_list = [];

		if (typeof obj.allow_all !== 'undefined') {
			allow_all = obj.allow_all;
		}

		if (typeof obj.allow_rules !== 'undefined') {
			allow_rules = obj.allow_rules;
		}

		if (typeof obj.allow_from_list !== 'undefined') {
			allow_from_list = obj.allow_from_list;
		}

		if (typeof obj.allow_subdomains !== 'undefined') {
			allow_subdomains = obj.allow_subdomains;
		}

		if (typeof obj.rule_list !== 'undefined') {
			rule_list = obj.rule_list;
		}

		document.getElementById("allow_all").checked = allow_all;
		document.getElementById("allow_rules").checked = allow_rules;
		document.getElementById("allow_from_list").selectedIndex = allow_from_list;
		document.getElementById("allow_subdomains").checked = allow_subdomains;

		var rule_list_box = document.getElementById("rule-list");
		rule_list_box.innerHTML = ""

		for (var index = 0; index < rule_list.length; index++) {
			var rule = rule_list[index];
			var opt = document.createElement('option');
			opt.appendChild( document.createTextNode(rule));
			opt.value = rule; 
			rule_list_box.appendChild(opt); 
		}
	})
}

window.addEventListener('load', function load(event){

    var add_btn = document.getElementById('add-rule');
    add_btn.addEventListener('click', function() { addRule() });

    var remove_btn = document.getElementById('remove-rule');
    remove_btn.addEventListener('click', function() { removeRule() });

    var allow_all = document.getElementById('allow_all');
    allow_all.addEventListener('click', function() { allowRuleRadioEvent() });

    var allow_rules = document.getElementById('allow_rules');
    allow_rules.addEventListener('click', function() { allowRuleRadioEvent() });

    var allow_subdomains = document.getElementById('allow_subdomains');
    allow_subdomains.addEventListener('click', function() { allowSubdomainCheckboxEvent() });

    var allow_from_list = document.getElementById('allow_from_list');
    allow_from_list.addEventListener('change', function() { allowRuleSelectEvent() });
    
    initialise();

});

